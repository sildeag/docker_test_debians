var classessentia_1_1util_1_1ComparePeakMagnitude =
[
    [ "operator()", "classessentia_1_1util_1_1ComparePeakMagnitude.html#a5836858dc4c8963372bd3a96214f7f99", null ],
    [ "_cmp1", "classessentia_1_1util_1_1ComparePeakMagnitude.html#ac27fb9c707f667ea1ad056902eed0dc6", null ],
    [ "_cmp2", "classessentia_1_1util_1_1ComparePeakMagnitude.html#a53ad8416807c7153d35153e40f2d6988", null ]
];