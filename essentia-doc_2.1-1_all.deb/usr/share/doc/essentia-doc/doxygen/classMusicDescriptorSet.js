var classMusicDescriptorSet =
[
    [ "nameSpace", "classMusicDescriptorSet.html#a437ed1a7595ff2ff9f1ea14c005e7322", null ],
    [ "options", "classMusicDescriptorSet.html#afc91b29da941343809e6f61327a016e4", null ]
];