var essentia_8h =
[
    [ "TypeMap", "classessentia_1_1TypeMap.html", "classessentia_1_1TypeMap" ],
    [ "registerEssentiaType", "essentia_8h.html#a10164ab2db26f8702af6a48cf5df4317", null ],
    [ "init", "essentia_8h.html#a7fb163426eccdb76576cdb3ca61a9e1f", null ],
    [ "isInitialized", "essentia_8h.html#abec8d9e6148e41927d9dfadd1515f30b", null ],
    [ "registerAlgorithm", "essentia_8h.html#a4e29ffd5a14e83bea8c36085b8c44c40", null ],
    [ "registerAlgorithm", "essentia_8h.html#ab18c82663c4281d3003ba11ec475072b", null ],
    [ "shutdown", "essentia_8h.html#a2e57f6d1f5cbc451b3ac5849437cf52c", null ],
    [ "version", "essentia_8h.html#aa31f487a99743d24af9076a3e11e5425", null ],
    [ "version_git_sha", "essentia_8h.html#a3b41995d837bbf8ea6b3bbc1897b7abe", null ]
];