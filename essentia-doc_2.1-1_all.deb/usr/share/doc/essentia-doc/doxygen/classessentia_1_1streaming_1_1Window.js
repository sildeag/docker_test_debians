var classessentia_1_1streaming_1_1Window =
[
    [ "Window", "classessentia_1_1streaming_1_1Window.html#a004cf7aac21e18b5b5675f1b635c3734", null ],
    [ "total", "classessentia_1_1streaming_1_1Window.html#abfaa5515321442b180faf36407cd2b7f", null ],
    [ "begin", "classessentia_1_1streaming_1_1Window.html#a9320720f4d683cc7c76f800be700ac35", null ],
    [ "end", "classessentia_1_1streaming_1_1Window.html#abce9f5dc9c83f2639b72024fdee5d388", null ],
    [ "turn", "classessentia_1_1streaming_1_1Window.html#aaefa47f4fdf865c2358c22b542a993e4", null ]
];