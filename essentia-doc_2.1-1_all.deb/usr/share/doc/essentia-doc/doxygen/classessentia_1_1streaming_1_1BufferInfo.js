var classessentia_1_1streaming_1_1BufferInfo =
[
    [ "BufferInfo", "classessentia_1_1streaming_1_1BufferInfo.html#aa99de2979ab23fe98e94f332a0c8b42c", null ],
    [ "maxContiguousElements", "classessentia_1_1streaming_1_1BufferInfo.html#a09427be1e90f5646faff6105a243fec6", null ],
    [ "size", "classessentia_1_1streaming_1_1BufferInfo.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];