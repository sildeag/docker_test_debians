var classessentia_1_1AlgorithmInfo =
[
    [ "AlgorithmCreator", "classessentia_1_1AlgorithmInfo.html#a6fa18e11814788bd3e4f1b419aad4597", null ],
    [ "category", "classessentia_1_1AlgorithmInfo.html#ad153dc5a1af8457498a6cecf0dba0b62", null ],
    [ "create", "classessentia_1_1AlgorithmInfo.html#a94c42b2b068052c2e492283b36d4c4c0", null ],
    [ "description", "classessentia_1_1AlgorithmInfo.html#a2e1454f6988673f814408646edaeb320", null ],
    [ "name", "classessentia_1_1AlgorithmInfo.html#a9b45b3e13bd9167aab02e17e08916231", null ]
];