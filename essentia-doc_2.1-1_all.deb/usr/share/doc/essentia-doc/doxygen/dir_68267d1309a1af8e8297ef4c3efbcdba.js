var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "essentia", "dir_e10a554efe7c1cb46c55e701d5e37144.html", "dir_e10a554efe7c1cb46c55e701d5e37144" ]
];