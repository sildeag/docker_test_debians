var classFreesoundSfxDescriptors =
[
    [ "FreesoundSfxDescriptors", "classFreesoundSfxDescriptors.html#aee0a4a344a63835b330e7d59225ba132", null ],
    [ "~FreesoundSfxDescriptors", "classFreesoundSfxDescriptors.html#a42d37c2cfdfb3c12579231135f61e05d", null ],
    [ "createHarmonicityNetwork", "classFreesoundSfxDescriptors.html#a64f0e2f1d04c7d535b2fc5970a45afc5", null ],
    [ "createNetwork", "classFreesoundSfxDescriptors.html#afa77de1bc9b1ce41d00e7191dc7cf04c", null ],
    [ "createPitchNetwork", "classFreesoundSfxDescriptors.html#aa3dae02686c2f8b43fa83e227304bc62", null ],
    [ "nameSpace", "classFreesoundSfxDescriptors.html#a437ed1a7595ff2ff9f1ea14c005e7322", null ]
];