var classessentia_1_1streaming_1_1DevNull =
[
    [ "DevNull", "classessentia_1_1streaming_1_1DevNull.html#a81790f4c13a881434e20319346ed7d7d", null ],
    [ "declareParameters", "classessentia_1_1streaming_1_1DevNull.html#ab0a952bddace70e7a7b6a0811ad4f8de", null ],
    [ "process", "classessentia_1_1streaming_1_1DevNull.html#a86bfe500975f4fef2bc07de0fb2f0e0c", null ],
    [ "_frames", "classessentia_1_1streaming_1_1DevNull.html#ad15787105c57c617bc61815f2ead8d3f", null ]
];