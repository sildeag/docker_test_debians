var configurable_8h =
[
    [ "Configurable", "classessentia_1_1Configurable.html", "classessentia_1_1Configurable" ],
    [ "INHERIT", "configurable_8h.html#a4ef69c19bbb60ef595c3c4d63ea385ae", null ],
    [ "compareByName", "configurable_8h.html#a7e363420443e846748a9704e111b6886", null ]
];