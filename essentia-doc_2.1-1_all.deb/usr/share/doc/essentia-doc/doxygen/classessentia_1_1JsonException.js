var classessentia_1_1JsonException =
[
    [ "JsonException", "classessentia_1_1JsonException.html#ae5bed911408038e9c8e1a161680239c2", null ]
];