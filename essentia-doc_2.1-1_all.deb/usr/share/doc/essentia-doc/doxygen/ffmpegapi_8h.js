var ffmpegapi_8h =
[
    [ "AV_PKT_FLAG_KEY", "ffmpegapi_8h.html#a75603d7c2b8adf5829f4fd2fb860168f", null ],
    [ "avformat_write_header", "ffmpegapi_8h.html#a4b7ea43b07adcafca23cde492d1d5669", null ],
    [ "avio_close", "ffmpegapi_8h.html#a04c6f74f01e98668c014531bfa20e2e6", null ],
    [ "AVIO_FLAG_WRITE", "ffmpegapi_8h.html#a5c9308f296545a8f3b7687d277a6dabc", null ],
    [ "avio_open", "ffmpegapi_8h.html#aac82a8482c95977621b733460cfdea39", null ]
];