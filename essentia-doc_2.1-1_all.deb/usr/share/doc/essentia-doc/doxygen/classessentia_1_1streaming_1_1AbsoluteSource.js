var classessentia_1_1streaming_1_1AbsoluteSource =
[
    [ "addReader", "classessentia_1_1streaming_1_1AbsoluteSource.html#a859186959ff1fa5dcc4764478411783e", null ]
];