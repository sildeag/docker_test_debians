var dir_f83737435eab5e599093071af982abf4 =
[
    [ "algorithms", "dir_b628a012d3b292d6787d2a9c2f091fe4.html", "dir_b628a012d3b292d6787d2a9c2f091fe4" ],
    [ "accumulatoralgorithm.h", "accumulatoralgorithm_8h.html", [
      [ "AccumulatorAlgorithm", "classessentia_1_1streaming_1_1AccumulatorAlgorithm.html", "classessentia_1_1streaming_1_1AccumulatorAlgorithm" ]
    ] ],
    [ "multiratebuffer.h", "multiratebuffer_8h.html", [
      [ "MultiRateBuffer", "classessentia_1_1streaming_1_1MultiRateBuffer.html", "classessentia_1_1streaming_1_1MultiRateBuffer" ]
    ] ],
    [ "phantombuffer.h", "phantombuffer_8h.html", [
      [ "Window", "classessentia_1_1streaming_1_1Window.html", "classessentia_1_1streaming_1_1Window" ],
      [ "PhantomBuffer", "classessentia_1_1streaming_1_1PhantomBuffer.html", "classessentia_1_1streaming_1_1PhantomBuffer" ]
    ] ],
    [ "phantombuffer_impl.h", "phantombuffer__impl_8h.html", null ],
    [ "sink.h", "sink_8h.html", [
      [ "Source", "classessentia_1_1streaming_1_1Source.html", "classessentia_1_1streaming_1_1Source" ],
      [ "Sink", "classessentia_1_1streaming_1_1Sink.html", "classessentia_1_1streaming_1_1Sink" ]
    ] ],
    [ "sinkbase.h", "sinkbase_8h.html", "sinkbase_8h" ],
    [ "sinkproxy.h", "sinkproxy_8h.html", "sinkproxy_8h" ],
    [ "source.h", "source_8h.html", "source_8h" ],
    [ "sourcebase.h", "sourcebase_8h.html", "sourcebase_8h" ],
    [ "sourceproxy.h", "sourceproxy_8h.html", "sourceproxy_8h" ],
    [ "streamingalgorithm.h", "streamingalgorithm_8h.html", "streamingalgorithm_8h" ],
    [ "streamingalgorithmcomposite.h", "streamingalgorithmcomposite_8h.html", [
      [ "ProcessStep", "classessentia_1_1streaming_1_1ProcessStep.html", "classessentia_1_1streaming_1_1ProcessStep" ],
      [ "ChainFrom", "classessentia_1_1streaming_1_1ChainFrom.html", "classessentia_1_1streaming_1_1ChainFrom" ],
      [ "SingleShot", "classessentia_1_1streaming_1_1SingleShot.html", "classessentia_1_1streaming_1_1SingleShot" ],
      [ "AlgorithmComposite", "classessentia_1_1streaming_1_1AlgorithmComposite.html", "classessentia_1_1streaming_1_1AlgorithmComposite" ]
    ] ],
    [ "streamingalgorithmwrapper.h", "streamingalgorithmwrapper_8h.html", "streamingalgorithmwrapper_8h" ]
];