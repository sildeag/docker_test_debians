var extractor__music_2extractor__version_8h =
[
    [ "MUSIC_EXTRACTOR_HL_VERSION", "extractor__music_2extractor__version_8h.html#a259d6bbba193d1df76e7e3df2f6e3114", null ],
    [ "MUSIC_EXTRACTOR_VERSION", "extractor__music_2extractor__version_8h.html#a9dc06bb5e48d427a086620f731a51e6f", null ]
];