var devnull_8h =
[
    [ "DevNull", "classessentia_1_1streaming_1_1DevNull.html", "classessentia_1_1streaming_1_1DevNull" ],
    [ "DevNullConnector", "devnull_8h.html#a86525423e05909061fdbe2961585a8a8", [
      [ "NOWHERE", "devnull_8h.html#a86525423e05909061fdbe2961585a8a8a8baa369a007f0229f710055dee398153", null ],
      [ "DEVNULL", "devnull_8h.html#a86525423e05909061fdbe2961585a8a8a98457b9fd43b3692c12db9b1d731e6e7", null ]
    ] ],
    [ "connect", "devnull_8h.html#a9d4ab571b5ce9195f0e98643876c47a5", null ],
    [ "disconnect", "devnull_8h.html#a2f57693ab6280c41b859febf90ee10ec", null ],
    [ "operator>>", "devnull_8h.html#a3138db7e51964ec8da929f64316184b5", null ]
];