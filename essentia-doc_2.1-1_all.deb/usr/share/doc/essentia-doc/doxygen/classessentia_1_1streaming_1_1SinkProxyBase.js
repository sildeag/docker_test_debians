var classessentia_1_1streaming_1_1SinkProxyBase =
[
    [ "SinkProxyBase", "classessentia_1_1streaming_1_1SinkProxyBase.html#abd6cdde356232e635fa820e586cda0ec", null ],
    [ "SinkProxyBase", "classessentia_1_1streaming_1_1SinkProxyBase.html#a58c3ac4a4f87a648fada36397215c321", null ],
    [ "~SinkProxyBase", "classessentia_1_1streaming_1_1SinkProxyBase.html#a4061c20aa6932416726c0ba2c7f0c9f3", null ],
    [ "acquire", "classessentia_1_1streaming_1_1SinkProxyBase.html#af9f5b35a212d21af601a8213ed325871", null ],
    [ "acquire", "classessentia_1_1streaming_1_1SinkProxyBase.html#a0b3e8243fc4e450b7b055e5e588bb286", null ],
    [ "acquireSize", "classessentia_1_1streaming_1_1SinkProxyBase.html#ad3785e168ddf7a4c87f7826c5081755c", null ],
    [ "attach", "classessentia_1_1streaming_1_1SinkProxyBase.html#a79a6daab443158d0fe8dfcc262ee5f55", null ],
    [ "buffer", "classessentia_1_1streaming_1_1SinkProxyBase.html#ac679143e59e3811962d01e30c5ebfcba", null ],
    [ "buffer", "classessentia_1_1streaming_1_1SinkProxyBase.html#acabfbb93e5c7173db75f47823ea74947", null ],
    [ "detach", "classessentia_1_1streaming_1_1SinkProxyBase.html#ac295bade8aee589f6718dfa79edc2a34", null ],
    [ "detach", "classessentia_1_1streaming_1_1SinkProxyBase.html#a01d040ad8213b147c868cadb1eab4d31", null ],
    [ "release", "classessentia_1_1streaming_1_1SinkProxyBase.html#a23b477d0e2d399f75d585d154c346591", null ],
    [ "release", "classessentia_1_1streaming_1_1SinkProxyBase.html#aeb2a2dd529e67b5c64182f4f17f6a915", null ],
    [ "releaseSize", "classessentia_1_1streaming_1_1SinkProxyBase.html#ab8d99a29c35032d9cb407a4b49e5eee6", null ],
    [ "setId", "classessentia_1_1streaming_1_1SinkProxyBase.html#ab6b46f7373d82d4e094cd7aa6b129fee", null ],
    [ "setSource", "classessentia_1_1streaming_1_1SinkProxyBase.html#aa749bc2996f29386ec8adc81452fe827", null ],
    [ "updateProxiedSink", "classessentia_1_1streaming_1_1SinkProxyBase.html#a32cd9094ae69466e6d0f92b600587643", null ],
    [ "attach", "classessentia_1_1streaming_1_1SinkProxyBase.html#abcc9e0260680871ca6e7cf6812d845d0", null ],
    [ "detach", "classessentia_1_1streaming_1_1SinkProxyBase.html#a0c2572b01f44b9958c943c65c86cc245", null ],
    [ "_proxiedSink", "classessentia_1_1streaming_1_1SinkProxyBase.html#af35763e3f0a687d8f3052648a9a07646", null ]
];