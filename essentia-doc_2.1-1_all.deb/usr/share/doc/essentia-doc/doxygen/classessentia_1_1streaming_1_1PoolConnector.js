var classessentia_1_1streaming_1_1PoolConnector =
[
    [ "PoolConnector", "classessentia_1_1streaming_1_1PoolConnector.html#a440e6cd6e3f723a6b9004402d2da6ec4", null ],
    [ "operator>>", "classessentia_1_1streaming_1_1PoolConnector.html#a5ce50a50d3eb3a397193574bee5a07fa", null ],
    [ "name", "classessentia_1_1streaming_1_1PoolConnector.html#a9b45b3e13bd9167aab02e17e08916231", null ],
    [ "pool", "classessentia_1_1streaming_1_1PoolConnector.html#ac95e61cb8f67bc1dd9f84c546c0cdcdc", null ]
];