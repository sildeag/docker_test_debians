var classessentia_1_1AsciiBox =
[
    [ "AsciiBox", "classessentia_1_1AsciiBox.html#af2c6e69c85cfac5b9c19bd3f794d179c", null ],
    [ "borderContains", "classessentia_1_1AsciiBox.html#a92aa896f73a8827e7132d5e6693a6bab", null ],
    [ "findBoxes", "classessentia_1_1AsciiBox.html#ae328b0b04cdcc39fe3a34cdcfb96c87a", null ],
    [ "isBox", "classessentia_1_1AsciiBox.html#a5c936126b473d4c06f24de93516a6114", null ],
    [ "height", "classessentia_1_1AsciiBox.html#ad12fc34ce789bce6c8a05d8a17138534", null ],
    [ "posX", "classessentia_1_1AsciiBox.html#ab34f89ef94db9dd6d3a04425dd6d9c9d", null ],
    [ "posY", "classessentia_1_1AsciiBox.html#a65ab2de052c17234c8a1db3fd3b868a9", null ],
    [ "title", "classessentia_1_1AsciiBox.html#ac30fed21fe991cc8475ce543929f8b72", null ],
    [ "width", "classessentia_1_1AsciiBox.html#a2474a5474cbff19523a51eb1de01cda4", null ]
];