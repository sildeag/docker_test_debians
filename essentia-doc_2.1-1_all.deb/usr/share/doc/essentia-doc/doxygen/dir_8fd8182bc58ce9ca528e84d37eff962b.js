var dir_8fd8182bc58ce9ca528e84d37eff962b =
[
    [ "extractor_version.h", "extractor__freesound_2extractor__version_8h.html", "extractor__freesound_2extractor__version_8h" ],
    [ "FreesoundDescriptorsSet.h", "FreesoundDescriptorsSet_8h.html", [
      [ "FreesoundDescriptorSet", "classFreesoundDescriptorSet.html", "classFreesoundDescriptorSet" ]
    ] ],
    [ "FreesoundLowlevelDescriptors.h", "FreesoundLowlevelDescriptors_8h.html", [
      [ "FreesoundLowlevelDescriptors", "classFreesoundLowlevelDescriptors.html", "classFreesoundLowlevelDescriptors" ]
    ] ],
    [ "FreesoundRhythmDescriptors.h", "FreesoundRhythmDescriptors_8h.html", [
      [ "FreesoundRhythmDescriptors", "classFreesoundRhythmDescriptors.html", "classFreesoundRhythmDescriptors" ]
    ] ],
    [ "FreesoundSfxDescriptors.h", "FreesoundSfxDescriptors_8h.html", [
      [ "FreesoundSfxDescriptors", "classFreesoundSfxDescriptors.html", "classFreesoundSfxDescriptors" ]
    ] ],
    [ "FreesoundTonalDescriptors.h", "FreesoundTonalDescriptors_8h.html", [
      [ "FreesoundTonalDescriptors", "classFreesoundTonalDescriptors.html", "classFreesoundTonalDescriptors" ]
    ] ]
];