var annotated_dup =
[
    [ "essentia", "namespaceessentia.html", "namespaceessentia" ],
    [ "JAMA", "namespaceJAMA.html", "namespaceJAMA" ],
    [ "TNT", "namespaceTNT.html", "namespaceTNT" ],
    [ "Condition", "classCondition.html", "classCondition" ],
    [ "FreesoundDescriptorSet", "classFreesoundDescriptorSet.html", "classFreesoundDescriptorSet" ],
    [ "FreesoundLowlevelDescriptors", "classFreesoundLowlevelDescriptors.html", "classFreesoundLowlevelDescriptors" ],
    [ "FreesoundRhythmDescriptors", "classFreesoundRhythmDescriptors.html", "classFreesoundRhythmDescriptors" ],
    [ "FreesoundSfxDescriptors", "classFreesoundSfxDescriptors.html", "classFreesoundSfxDescriptors" ],
    [ "FreesoundTonalDescriptors", "classFreesoundTonalDescriptors.html", "classFreesoundTonalDescriptors" ],
    [ "MTRand", "classMTRand.html", "classMTRand" ],
    [ "MusicDescriptorSet", "classMusicDescriptorSet.html", "classMusicDescriptorSet" ],
    [ "MusicLowlevelDescriptors", "classMusicLowlevelDescriptors.html", "classMusicLowlevelDescriptors" ],
    [ "MusicRhythmDescriptors", "classMusicRhythmDescriptors.html", "classMusicRhythmDescriptors" ],
    [ "MusicTonalDescriptors", "classMusicTonalDescriptors.html", "classMusicTonalDescriptors" ]
];