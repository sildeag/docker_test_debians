var classMusicLowlevelDescriptors =
[
    [ "MusicLowlevelDescriptors", "classMusicLowlevelDescriptors.html#a32ac4eb4d436c7e490b3c31d4e39a345", null ],
    [ "~MusicLowlevelDescriptors", "classMusicLowlevelDescriptors.html#a26c4f95f525ab8b9482f199d905dfa82", null ],
    [ "computeAverageLoudness", "classMusicLowlevelDescriptors.html#a8d7e678c8c72d9bcf24c16c3fe49ec2b", null ],
    [ "createNetworkEqLoud", "classMusicLowlevelDescriptors.html#ac4208a588c13c178ea8d617428e8d498", null ],
    [ "createNetworkLoudness", "classMusicLowlevelDescriptors.html#a898269928a8649e9e4bb6d60d94a90f2", null ],
    [ "createNetworkNeqLoud", "classMusicLowlevelDescriptors.html#a9fe66a469713b4e4eb2cf6ff4a3f9b19", null ],
    [ "nameSpace", "classMusicLowlevelDescriptors.html#a437ed1a7595ff2ff9f1ea14c005e7322", null ]
];