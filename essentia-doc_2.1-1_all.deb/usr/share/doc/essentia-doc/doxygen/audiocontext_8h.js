var audiocontext_8h =
[
    [ "AudioContext", "classessentia_1_1AudioContext.html", "classessentia_1_1AudioContext" ],
    [ "MAX_AUDIO_FRAME_SIZE", "audiocontext_8h.html#a8255d7a576a02a846c8c09a74388d2f4", null ]
];