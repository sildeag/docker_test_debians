var bpmutil_8h =
[
    [ "areEqual", "bpmutil_8h.html#ab09ded336d79b117773f0a0edffc5f8f", null ],
    [ "areHarmonics", "bpmutil_8h.html#ad72049b32254e93d9b405f37b5a7ca7b", null ],
    [ "bpmDistance", "bpmutil_8h.html#a488a8011779296eee1668b334014cf41", null ],
    [ "bpmToLag", "bpmutil_8h.html#a8e95bea4a8a0a29d0f3ad5197e994d2c", null ],
    [ "greatestCommonDivisor", "bpmutil_8h.html#aa3aec0278e7b2e47b2fd062851d42182", null ],
    [ "lagToBpm", "bpmutil_8h.html#a9ce0b32606e3bad4922a680214e0fe0a", null ],
    [ "longestChain", "bpmutil_8h.html#aefb55aae9d6a38169bf00ff8b3c182e3", null ],
    [ "postProcessTicks", "bpmutil_8h.html#a8ab4de65e4bda4c09e046bdc93988609", null ],
    [ "postProcessTicks", "bpmutil_8h.html#a5eefb68a5c67a520dd8f91a807c6bfd7", null ],
    [ "roundBpms", "bpmutil_8h.html#a5c4ceba5df93b962972e38da25d10cd5", null ]
];