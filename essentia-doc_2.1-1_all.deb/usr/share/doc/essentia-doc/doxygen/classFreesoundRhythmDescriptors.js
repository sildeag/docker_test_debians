var classFreesoundRhythmDescriptors =
[
    [ "FreesoundRhythmDescriptors", "classFreesoundRhythmDescriptors.html#a68d63447bc0605910158efbaf7a1b8c9", null ],
    [ "~FreesoundRhythmDescriptors", "classFreesoundRhythmDescriptors.html#a7cbdcc984721fd93cdbb3e303a06a4e0", null ],
    [ "createNetwork", "classFreesoundRhythmDescriptors.html#afa77de1bc9b1ce41d00e7191dc7cf04c", null ],
    [ "createNetworkBeatsLoudness", "classFreesoundRhythmDescriptors.html#a76b7cc0195415589224ec2b6e3e1dcfe", null ],
    [ "nameSpace", "classFreesoundRhythmDescriptors.html#a437ed1a7595ff2ff9f1ea14c005e7322", null ]
];