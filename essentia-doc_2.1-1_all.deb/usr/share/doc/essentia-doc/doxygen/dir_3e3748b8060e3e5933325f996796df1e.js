var dir_3e3748b8060e3e5933325f996796df1e =
[
    [ "jama_cholesky.h", "jama__cholesky_8h.html", [
      [ "Cholesky", "classJAMA_1_1Cholesky.html", "classJAMA_1_1Cholesky" ]
    ] ],
    [ "jama_eig.h", "jama__eig_8h.html", [
      [ "Eigenvalue", "classJAMA_1_1Eigenvalue.html", "classJAMA_1_1Eigenvalue" ]
    ] ],
    [ "jama_lu.h", "jama__lu_8h.html", [
      [ "LU", "classJAMA_1_1LU.html", "classJAMA_1_1LU" ]
    ] ],
    [ "jama_qr.h", "jama__qr_8h.html", [
      [ "QR", "classJAMA_1_1QR.html", "classJAMA_1_1QR" ]
    ] ],
    [ "jama_svd.h", "jama__svd_8h.html", [
      [ "SVD", "classJAMA_1_1SVD.html", "classJAMA_1_1SVD" ]
    ] ],
    [ "tnt.h", "tnt_8h.html", null ],
    [ "tnt2essentiautils.h", "tnt2essentiautils_8h.html", "tnt2essentiautils_8h" ],
    [ "tnt2vector.h", "tnt2vector_8h.html", "tnt2vector_8h" ],
    [ "tnt_array1d.h", "tnt__array1d_8h.html", [
      [ "Array1D", "classTNT_1_1Array1D.html", "classTNT_1_1Array1D" ]
    ] ],
    [ "tnt_array1d_utils.h", "tnt__array1d__utils_8h.html", "tnt__array1d__utils_8h" ],
    [ "tnt_array2d.h", "tnt__array2d_8h.html", [
      [ "Array2D", "classTNT_1_1Array2D.html", "classTNT_1_1Array2D" ]
    ] ],
    [ "tnt_array2d_utils.h", "tnt__array2d__utils_8h.html", "tnt__array2d__utils_8h" ],
    [ "tnt_array3d.h", "tnt__array3d_8h.html", [
      [ "Array3D", "classTNT_1_1Array3D.html", "classTNT_1_1Array3D" ]
    ] ],
    [ "tnt_array3d_utils.h", "tnt__array3d__utils_8h.html", "tnt__array3d__utils_8h" ],
    [ "tnt_cmat.h", "tnt__cmat_8h.html", "tnt__cmat_8h" ],
    [ "tnt_fortran_array1d.h", "tnt__fortran__array1d_8h.html", [
      [ "Fortran_Array1D", "classTNT_1_1Fortran__Array1D.html", "classTNT_1_1Fortran__Array1D" ]
    ] ],
    [ "tnt_fortran_array1d_utils.h", "tnt__fortran__array1d__utils_8h.html", "tnt__fortran__array1d__utils_8h" ],
    [ "tnt_fortran_array2d.h", "tnt__fortran__array2d_8h.html", [
      [ "Fortran_Array2D", "classTNT_1_1Fortran__Array2D.html", "classTNT_1_1Fortran__Array2D" ]
    ] ],
    [ "tnt_fortran_array2d_utils.h", "tnt__fortran__array2d__utils_8h.html", "tnt__fortran__array2d__utils_8h" ],
    [ "tnt_fortran_array3d.h", "tnt__fortran__array3d_8h.html", [
      [ "Fortran_Array3D", "classTNT_1_1Fortran__Array3D.html", "classTNT_1_1Fortran__Array3D" ]
    ] ],
    [ "tnt_fortran_array3d_utils.h", "tnt__fortran__array3d__utils_8h.html", "tnt__fortran__array3d__utils_8h" ],
    [ "tnt_i_refvec.h", "tnt__i__refvec_8h.html", "tnt__i__refvec_8h" ],
    [ "tnt_math_utils.h", "tnt__math__utils_8h.html", "tnt__math__utils_8h" ],
    [ "tnt_sparse_matrix_csr.h", "tnt__sparse__matrix__csr_8h.html", [
      [ "Sparse_Matrix_CompRow", "classTNT_1_1Sparse__Matrix__CompRow.html", "classTNT_1_1Sparse__Matrix__CompRow" ]
    ] ],
    [ "tnt_stopwatch.h", "tnt__stopwatch_8h.html", "tnt__stopwatch_8h" ],
    [ "tnt_subscript.h", "tnt__subscript_8h.html", "tnt__subscript_8h" ],
    [ "tnt_vec.h", "tnt__vec_8h.html", "tnt__vec_8h" ],
    [ "tnt_version.h", "tnt__version_8h.html", "tnt__version_8h" ]
];