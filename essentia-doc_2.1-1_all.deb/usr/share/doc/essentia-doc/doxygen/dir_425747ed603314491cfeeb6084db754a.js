var dir_425747ed603314491cfeeb6084db754a =
[
    [ "extractor_version.h", "extractor__music_2extractor__version_8h.html", "extractor__music_2extractor__version_8h" ],
    [ "MusicDescriptorsSet.h", "MusicDescriptorsSet_8h.html", [
      [ "MusicDescriptorSet", "classMusicDescriptorSet.html", "classMusicDescriptorSet" ]
    ] ],
    [ "MusicLowlevelDescriptors.h", "MusicLowlevelDescriptors_8h.html", [
      [ "MusicLowlevelDescriptors", "classMusicLowlevelDescriptors.html", "classMusicLowlevelDescriptors" ]
    ] ],
    [ "MusicRhythmDescriptors.h", "MusicRhythmDescriptors_8h.html", [
      [ "MusicRhythmDescriptors", "classMusicRhythmDescriptors.html", "classMusicRhythmDescriptors" ]
    ] ],
    [ "MusicTonalDescriptors.h", "MusicTonalDescriptors_8h.html", [
      [ "MusicTonalDescriptors", "classMusicTonalDescriptors.html", "classMusicTonalDescriptors" ]
    ] ],
    [ "tagwhitelist.h", "tagwhitelist_8h.html", "tagwhitelist_8h" ]
];