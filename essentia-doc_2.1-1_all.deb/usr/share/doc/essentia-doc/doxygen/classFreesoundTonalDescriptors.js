var classFreesoundTonalDescriptors =
[
    [ "FreesoundTonalDescriptors", "classFreesoundTonalDescriptors.html#a022d8d1bd1945b69357ef14805cfa95b", null ],
    [ "~FreesoundTonalDescriptors", "classFreesoundTonalDescriptors.html#a35513b394f130a4a5382301977943b7e", null ],
    [ "createNetwork", "classFreesoundTonalDescriptors.html#afa77de1bc9b1ce41d00e7191dc7cf04c", null ],
    [ "nameSpace", "classFreesoundTonalDescriptors.html#a437ed1a7595ff2ff9f1ea14c005e7322", null ]
];