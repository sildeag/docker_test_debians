var classessentia_1_1util_1_1BPF =
[
    [ "BPF", "classessentia_1_1util_1_1BPF.html#a2f9f7504e5619895b8d774c11aa807d7", null ],
    [ "BPF", "classessentia_1_1util_1_1BPF.html#afcec86e8413c215cd50e3551ddbef8e5", null ],
    [ "init", "classessentia_1_1util_1_1BPF.html#a004ee17b4ae8bffdc656276c5b20c818", null ],
    [ "operator()", "classessentia_1_1util_1_1BPF.html#aa6517dd8e83c72b8dfb72ef915d5f096", null ],
    [ "_slopes", "classessentia_1_1util_1_1BPF.html#a9ef96c1bb6caee45e0b877f096069662", null ],
    [ "_xPoints", "classessentia_1_1util_1_1BPF.html#a6f1eb28b8f969dbe5bf1a6ca3ed4509f", null ],
    [ "_yPoints", "classessentia_1_1util_1_1BPF.html#a3e74bc2f7b02866cae317599bacdd3f0", null ]
];