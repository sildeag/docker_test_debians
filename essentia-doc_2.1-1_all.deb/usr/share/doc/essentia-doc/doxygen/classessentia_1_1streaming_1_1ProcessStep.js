var classessentia_1_1streaming_1_1ProcessStep =
[
    [ "ProcessStep", "classessentia_1_1streaming_1_1ProcessStep.html#adfcbf625a343ac48ebfd196f2719ea82", null ],
    [ "algorithm", "classessentia_1_1streaming_1_1ProcessStep.html#a066d323046115a4af94e68cd5b8077b4", null ],
    [ "type", "classessentia_1_1streaming_1_1ProcessStep.html#af5c2dafc43410ca5ead816839f1489fe", null ],
    [ "_algo", "classessentia_1_1streaming_1_1ProcessStep.html#a2d528f0a6c5d0834d943bd54e8892fdb", null ],
    [ "_type", "classessentia_1_1streaming_1_1ProcessStep.html#a4c686aa2e688932eb399b2ca0a9b39bb", null ]
];