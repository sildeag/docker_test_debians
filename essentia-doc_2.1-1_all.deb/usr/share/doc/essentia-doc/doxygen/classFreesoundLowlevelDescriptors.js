var classFreesoundLowlevelDescriptors =
[
    [ "FreesoundLowlevelDescriptors", "classFreesoundLowlevelDescriptors.html#afa1637fbd6ee1bb5582cab6af756a512", null ],
    [ "~FreesoundLowlevelDescriptors", "classFreesoundLowlevelDescriptors.html#a74c1d5b5a23d9ca6763ccec33706a928", null ],
    [ "computeAverageLoudness", "classFreesoundLowlevelDescriptors.html#a8d7e678c8c72d9bcf24c16c3fe49ec2b", null ],
    [ "createNetwork", "classFreesoundLowlevelDescriptors.html#afa77de1bc9b1ce41d00e7191dc7cf04c", null ],
    [ "nameSpace", "classFreesoundLowlevelDescriptors.html#a437ed1a7595ff2ff9f1ea14c005e7322", null ]
];