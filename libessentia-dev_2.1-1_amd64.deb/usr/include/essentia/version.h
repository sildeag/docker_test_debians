
#ifndef VERSION_H_
#define VERSION_H_
#define ESSENTIA_VERSION "2.1-dev"
#define ESSENTIA_GIT_SHA "v2.1_beta3-519-g7c69c9c9-dirty"
#endif /* VERSION_H_ */
